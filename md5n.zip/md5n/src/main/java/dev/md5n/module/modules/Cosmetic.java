package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Colors;
import dev.md5n.util.Fx;
import net.minecraft.util.math.Vec3d;

import java.util.concurrent.ThreadLocalRandom;

/** قاعدة الكوزمتك: كلها مبنية من جسيمات حول لاعبك (تظهر لك أنت بس). */
public abstract class Cosmetic extends Module {
    protected static final double TAU = Math.PI * 2.0;

    protected final ModeSetting style;
    protected final ModeSetting color;
    protected final NumSetting size;
    protected final NumSetting density;
    protected final BoolSetting vfx;
    protected final ModeSetting vfxType;
    protected final BoolSetting firstPerson;

    // إحداثيات اللاعب ومحاوره (تتحدث كل تيك)
    protected double t, ax, ay, az, fx, fz, rx, rz, height, pvx, pvy, pvz, speed;
    protected int tick;

    protected Cosmetic(String name, String description, String[] styles) {
        super(name, Category.COSMETIC, description);
        style = mode("Style", styles[0], "10 styles. Click to cycle through them", styles);
        color = mode("Color", "Theme", "Used only when Theme > Sync Cosmetics is off", Colors.MODES);
        size = num("Size", 1.0, 0.5, 2.0, 0.1, "Scale of the cosmetic");
        density = num("Density", 1.0, 0.3, 3.0, 0.1, "How many particles it uses");
        vfx = bool("VFX", false, "Add extra particle effects on top of this cosmetic");
        vfxType = mode("VFX Type", "Sparkle", "Which effect is added when VFX is on",
                "Sparkle", "Glow", "Flame", "Soul", "Magic", "Electric", "Snow", "Petals");
        firstPerson = bool("First Person", false, "Also show it in first person (otherwise press F5 to see it)");
    }

    /** ارسم الستايل الحالي (يُستدعى كل تيك). */
    protected abstract void emit(String styleName);

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (!firstPerson.get() && mc.options.getPerspective().isFirstPerson()) return;
        prepare();
        emit(style.get());
    }

    protected void prepare() {
        t = System.currentTimeMillis() / 1000.0;
        double yaw = Math.toRadians(mc.player.bodyYaw);
        fx = -Math.sin(yaw);
        fz = Math.cos(yaw);
        rx = -Math.cos(yaw);
        rz = -Math.sin(yaw);
        ax = mc.player.getX();
        ay = mc.player.getY();
        az = mc.player.getZ();
        height = mc.player.getHeight();
        Vec3d v = mc.player.getVelocity();
        pvx = v.x;
        pvy = v.y;
        pvz = v.z;
        speed = Math.sqrt(pvx * pvx + pvz * pvz);
        tick++;
    }

    // ------------------------------------------------------------ أدوات

    protected static double rnd() {
        return ThreadLocalRandom.current().nextDouble();
    }

    protected static double spread(double range) {
        return (rnd() * 2.0 - 1.0) * range;
    }

    protected int n(double base) {
        double v = base * density.get();
        int k = (int) v;
        if (rnd() < v - k) k++;
        return k;
    }

    /** اللون الحالي (phase بين 0 و1 للتدرجات). */
    protected int col(double phase) {
        return Colors.resolve(color.get(), t, phase);
    }

    protected double worldX(double lx, double lz) {
        return ax + rx * lx + fx * lz;
    }

    protected double worldZ(double lx, double lz) {
        return az + rz * lx + fz * lz;
    }

    private void spawn(double lx, double ly, double lz, int rgb, double vx, double vy, double vz, boolean attach) {
        double k = attach ? 0.9 : 0.0;
        spawnWorld(worldX(lx, lz), ay + ly, worldZ(lx, lz), rgb, vx + pvx * k, vy + pvy * k, vz + pvz * k);
    }

    /** يطلع جسيمة بإحداثيات العالم + تأثير VFX لو مفعّل. */
    protected void spawnWorld(double x, double y, double z, int rgb, double vx, double vy, double vz) {
        Fx.dust(rgb, (float) (0.65 * size.get()), x, y, z, vx, vy, vz);
        if (vfx.get() && rnd() < 0.10) {
            Fx.vfx(vfxType.get(), x, y, z, vx * 0.2, 0.01, vz * 0.2);
        }
    }

    /** جسيمة ملتصقة باللاعب (تتحرك معه). lx = يمين، ly = فوق، lz = قدام. */
    protected void put(double lx, double ly, double lz, int rgb) {
        spawn(lx, ly, lz, rgb, 0.0, 0.0, 0.0, true);
    }

    protected void putV(double lx, double ly, double lz, int rgb, double vx, double vy, double vz) {
        spawn(lx, ly, lz, rgb, vx, vy, vz, true);
    }

    /** جسيمة تنزل بالعالم وتتركها وراك (للتريل). */
    protected void free(double lx, double ly, double lz, int rgb, double vx, double vy, double vz) {
        spawn(lx, ly, lz, rgb, vx, vy, vz, false);
    }

    protected void line(double x1, double y1, double z1, double x2, double y2, double z2, int pts, int rgb) {
        for (int i = 0; i < pts; i++) {
            double f = pts == 1 ? 0.0 : i / (double) (pts - 1);
            put(x1 + (x2 - x1) * f, y1 + (y2 - y1) * f, z1 + (z2 - z1) * f, rgb);
        }
    }

    /** دائرة أفقية. */
    protected void hring(double cx, double cy, double cz, double r, int pts, double rot, int rgb) {
        for (int i = 0; i < pts; i++) {
            double a = rot + i * TAU / pts;
            put(cx + Math.cos(a) * r, cy, cz + Math.sin(a) * r, rgb);
        }
    }

    /** دائرة عمودية (على مستوى يمين-فوق). */
    protected void vring(double cx, double cy, double cz, double r, int pts, double rot, int rgb) {
        for (int i = 0; i < pts; i++) {
            double a = rot + i * TAU / pts;
            put(cx + Math.cos(a) * r, cy + Math.sin(a) * r, cz, rgb);
        }
    }
}
