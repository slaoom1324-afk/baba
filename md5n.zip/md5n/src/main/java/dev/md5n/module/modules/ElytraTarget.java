package dev.md5n.module.modules;

import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.setting.KeySetting;
import dev.md5n.setting.ModeSetting;
import dev.md5n.setting.NumSetting;
import dev.md5n.util.Fireworks;
import dev.md5n.util.Sfx;
import dev.md5n.util.Targets;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public class ElytraTarget extends Module {
    private final KeySetting lockKey = keybind("Lock Key", GLFW.GLFW_KEY_G, "Press while flying to lock on the target in front of you");
    private final ModeSetting mode = mode("Mode", "Smooth", "Smooth turns gradually, Direct points straight at the target", "Smooth", "Direct");
    private final NumSetting range = num("Lock Range", 100, 10, 200, 5, "Max distance to lock a target");
    private final NumSetting stopDistance = num("Stop Distance", 2, 0, 10, 0.5, "Stop steering when this close");
    private final NumSetting smooth = num("Smooth Speed", 0.20, 0.01, 1.0, 0.01, "How fast Smooth mode turns");
    private final NumSetting maxStep = num("Max Step", 6, 1, 30, 1, "Max degrees turned per tick in Smooth mode");
    private final BoolSetting autoFirework = bool("Auto Firework", true, "Fire rockets to keep up with the locked target");
    private final NumSetting minSpeed = num("Min Speed (b/s)", 25, 5, 60, 1, "Fire a rocket when slower than this");
    private final NumSetting delay = num("Firework Delay", 25, 5, 60, 1, "Ticks between rockets (20 = 1 second)");
    private final BoolSetting players = bool("Players", true, "Lock onto players");
    private final BoolSetting hostile = bool("Hostile", false, "Lock onto hostile mobs");
    private final BoolSetting passive = bool("Passive", false, "Lock onto animals and villagers");

    private int lockedId = -1;
    private int timer;
    private String info;

    public ElytraTarget() {
        super("ElytraTarget", Category.MOVEMENT, "Lock a target, then fly after it with fireworks");
    }

    /** نص يعرضه الـ HUD لما يكون فيه هدف مقفول. */
    public String hudText() {
        return isEnabled() ? info : null;
    }

    @Override
    protected void onDisable() {
        lockedId = -1;
        info = null;
    }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null) return;
        if (timer > 0) timer--;
        if (mc.currentScreen != null) return;

        long window = mc.getWindow().getHandle();
        if (lockKey.consumePress(window)) toggleLock();

        if (lockedId == -1) {
            info = null;
            return;
        }

        Entity entity = mc.world.getEntityById(lockedId);
        if (!(entity instanceof LivingEntity target)) {
            unlock("target lost");
            return;
        }
        if (!target.isAlive()) {
            unlock("target gone");
            return;
        }

        double dist = mc.player.distanceTo(target);
        info = target.getName().getString() + "  " + Math.round(dist) + "m";

        if (!mc.player.isGliding()) return;

        if (dist >= stopDistance.get()) steer(target);

        if (autoFirework.get() && timer == 0 && dist > stopDistance.get() + 6) {
            double speed = mc.player.getVelocity().length() * 20.0;
            if (speed < minSpeed.get() && Fireworks.use()) timer = delay.getInt();
        }
    }

    private void toggleLock() {
        if (lockedId != -1) {
            unlock("unlocked");
            return;
        }
        LivingEntity best = findBest();
        if (best == null) {
            message("no target in range");
            return;
        }
        lockedId = best.getId();
        Sfx.on();
        message("locked " + best.getName().getString());
    }

    private void unlock(String reason) {
        lockedId = -1;
        info = null;
        Sfx.off();
        message(reason);
    }

    private void message(String text) {
        mc.inGameHud.setOverlayMessage(Text.literal("ElytraTarget: " + text), false);
    }

    /** أقرب هدف لاتجاه نظرك. */
    private LivingEntity findBest() {
        Vec3d eye = mc.player.getEyePos();
        Vec3d look = mc.player.getRotationVec(1.0f);
        double bestDot = 0.0;
        LivingEntity best = null;

        for (Entity e : mc.world.getEntities()) {
            if (!Targets.valid(e, players.get(), hostile.get(), passive.get())) continue;
            LivingEntity living = (LivingEntity) e;
            if (mc.player.distanceTo(living) > range.get()) continue;

            Vec3d to = living.getPos().add(0, living.getHeight() * 0.5, 0).subtract(eye).normalize();
            double dot = look.dotProduct(to);
            if (dot > bestDot) {
                bestDot = dot;
                best = living;
            }
        }
        return best;
    }

    private void steer(LivingEntity target) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d aim = target.getPos().add(0, target.getHeight() * 0.5, 0);

        double dx = aim.x - eye.x;
        double dy = aim.y - eye.y;
        double dz = aim.z - eye.z;
        double horizontal = Math.sqrt(dx * dx + dz * dz);

        float targetYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float targetPitch = MathHelper.clamp((float) -Math.toDegrees(Math.atan2(dy, horizontal)), -90f, 90f);

        if (mode.is("Direct")) {
            mc.player.setYaw(targetYaw);
            mc.player.setPitch(targetPitch);
            return;
        }

        float yawDiff = MathHelper.wrapDegrees(targetYaw - mc.player.getYaw());
        float pitchDiff = targetPitch - mc.player.getPitch();

        float step = maxStep.getFloat();
        float yawStep = MathHelper.clamp(yawDiff * smooth.getFloat(), -step, step);
        float pitchStep = MathHelper.clamp(pitchDiff * smooth.getFloat(), -step, step);

        mc.player.setYaw(mc.player.getYaw() + yawStep);
        mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + pitchStep, -90f, 90f));
    }
}
