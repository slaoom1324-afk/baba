package dev.md5n.module.modules;

import dev.md5n.Md5n;
import dev.md5n.module.Category;
import dev.md5n.module.Module;
import dev.md5n.setting.BoolSetting;
import dev.md5n.util.Draw;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class Hud extends Module {
    private static final int WHITE = 0xFFFFFFFF;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    private final BoolSetting watermark = bool("Watermark", true, "Show the client name and version");
    private final BoolSetting coords = bool("Coordinates", true, "Show your XYZ position");
    private final BoolSetting infoBar = bool("Info Bar", true, "Name, FPS, server and clock");
    private final BoolSetting speedGraph = bool("Speed Graph", true, "Show your speed with a small graph");
    private final BoolSetting moduleList = bool("Module List", true, "List enabled modules on the right");

    private final float[] history = new float[36];
    private double lastX, lastZ;
    private boolean hasLast;
    private float shownSpeed;
    private final Map<Module, Float> listAnim = new HashMap<>();
    private long lastNs;

    public Hud() {
        super("HUD", Category.VISUAL, "Glass HUD: coordinates, info bar, speed graph and module list");
    }

    @Override
    public void onTick() {
        if (mc.player == null) {
            hasLast = false;
            return;
        }
        double x = mc.player.getX();
        double z = mc.player.getZ();
        double speed = 0;
        if (hasLast) speed = Math.sqrt((x - lastX) * (x - lastX) + (z - lastZ) * (z - lastZ)) * 20.0;
        lastX = x;
        lastZ = z;
        hasLast = true;
        if (speed > 200) speed = 0;

        System.arraycopy(history, 1, history, 0, history.length - 1);
        history[history.length - 1] = (float) speed;
        shownSpeed += (float) ((speed - shownSpeed) * 0.25);
    }

    @Override
    public void onHudRender(DrawContext ctx) {
        if (mc.player == null) return;
        TextRenderer tr = mc.textRenderer;

        ThemeSettings theme = Md5n.modules.get(ThemeSettings.class);
        int accent = theme == null ? 0xFF55FFFF : theme.accent();

        long nowNs = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (nowNs - lastNs) / 1_000_000_000f);
        lastNs = nowNs;

        if (theme != null && theme.glass()) {
            renderGlass(ctx, tr, theme, accent, dt);
        } else {
            renderClassic(ctx, tr, accent);
        }
    }

    // ------------------------------------------------------------ Classic

    private void renderClassic(DrawContext ctx, TextRenderer tr, int accent) {
        int ly = 4;
        if (watermark.get()) {
            ctx.drawTextWithShadow(tr, Md5n.NAME + " " + Md5n.VERSION, 4, ly, accent);
            ly += 12;
        }
        if (infoBar.get()) {
            ctx.drawTextWithShadow(tr, mc.getCurrentFps() + " FPS", 4, ly, WHITE);
            ly += 12;
        }
        if (coords.get()) {
            ctx.drawTextWithShadow(tr, String.format(Locale.ROOT, "XYZ %.1f %.1f %.1f",
                    mc.player.getX(), mc.player.getY(), mc.player.getZ()), 4, ly, WHITE);
            ly += 12;
        }
        if (speedGraph.get()) {
            ctx.drawTextWithShadow(tr, String.format(Locale.ROOT, "Speed %.1f b/s", shownSpeed), 4, ly, WHITE);
            ly += 12;
        }

        ElytraTarget elytraTarget = Md5n.modules.get(ElytraTarget.class);
        String lock = elytraTarget == null ? null : elytraTarget.hudText();
        if (lock != null) {
            ctx.drawTextWithShadow(tr, "Locked: " + lock, 4, ly, accent);
        }

        if (moduleList.get()) {
            int width = ctx.getScaledWindowWidth();
            int y = 4;
            for (Module m : Md5n.modules.all()) {
                if (m == this || !m.isEnabled()) continue;
                ctx.drawTextWithShadow(tr, m.name, width - tr.getWidth(m.name) - 4, y, accent);
                y += 11;
            }
        }
    }

    // ------------------------------------------------------------ Glass

    private float approach(ThemeSettings theme, Module m, float target, float step) {
        float cur = listAnim.getOrDefault(m, 0f);
        if (!theme.animations()) cur = target;
        else if (cur < target) cur = Math.min(target, cur + step);
        else if (cur > target) cur = Math.max(target, cur - step);
        listAnim.put(m, cur);
        return cur;
    }

    private void pillAt(DrawContext ctx, TextRenderer tr, ThemeSettings theme, int accent, float pulse,
                        int x, int y, String text, int textColor, float a) {
        int pw = tr.getWidth(text) + 14;
        Draw.glass(ctx, x, y, x + pw, y + 16, 6,
                Draw.alpha(theme.header(), 0.78f * a),
                Draw.alpha(accent, (0.45f + 0.15f * pulse) * a),
                Draw.alpha(accent, 0.07f * a));
        int col = Draw.alpha(textColor, a);
        if ((col >>> 24) >= 12) ctx.drawTextWithShadow(tr, text, x + 7, y + 4, col);
    }

    private void renderGlass(DrawContext ctx, TextRenderer tr, ThemeSettings theme, int accent, float dt) {
        int sw = ctx.getScaledWindowWidth();
        int sh = ctx.getScaledWindowHeight();
        float pulse = (float) (0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 700.0));

        // الشعار (أعلى اليسار)
        if (watermark.get()) {
            pillAt(ctx, tr, theme, accent, pulse, 6, 6, Md5n.NAME + " " + Md5n.VERSION, accent, 1f);
        }

        // الإحداثيات (أعلى الوسط)
        int y = 6;
        if (coords.get()) {
            String s = "x " + (int) Math.floor(mc.player.getX())
                    + "    y " + (int) Math.floor(mc.player.getY())
                    + "    z " + (int) Math.floor(mc.player.getZ());
            int pw = tr.getWidth(s) + 14;
            pillAt(ctx, tr, theme, accent, pulse, sw / 2 - pw / 2, y, s, WHITE, 1f);
            y += 21;
        }

        // شريط المعلومات: الاسم | FPS | السيرفر | الساعة
        if (infoBar.get()) {
            var entry = mc.getCurrentServerEntry();
            String server = entry == null ? "singleplayer" : entry.address;
            String[] parts = {
                    mc.player.getName().getString(),
                    mc.getCurrentFps() + " FPS",
                    server,
                    LocalTime.now().format(CLOCK)
            };
            int gap = 14;
            int total = 14;
            for (int i = 0; i < parts.length; i++) {
                total += tr.getWidth(parts[i]);
                if (i < parts.length - 1) total += gap;
            }
            int x = sw / 2 - total / 2;
            Draw.glass(ctx, x, y, x + total, y + 16, 6,
                    Draw.alpha(theme.header(), 0.78f),
                    Draw.alpha(accent, 0.45f + 0.15f * pulse),
                    Draw.alpha(accent, 0.07f));
            int cx = x + 7;
            for (int i = 0; i < parts.length; i++) {
                ctx.drawTextWithShadow(tr, parts[i], cx, y + 4, i == 0 ? accent : WHITE);
                cx += tr.getWidth(parts[i]);
                if (i < parts.length - 1) {
                    ctx.drawTextWithShadow(tr, "|", cx + gap / 2 - 1, y + 4, theme.subtext());
                    cx += gap;
                }
            }
            y += 21;
        }

        // السرعة مع رسم بياني صغير (أسفل اليسار)
        if (speedGraph.get()) {
            int wx = 8, ww = 118, wh = 34;
            int wy = sh - wh - 30;
            Draw.glass(ctx, wx, wy, wx + ww, wy + wh, 6,
                    Draw.alpha(theme.header(), 0.78f),
                    Draw.alpha(accent, 0.45f + 0.15f * pulse),
                    Draw.alpha(accent, 0.07f));
            ctx.drawTextWithShadow(tr, String.format(Locale.ROOT, "Speed - %.1f b/s", shownSpeed), wx + 7, wy + 5, WHITE);

            float max = 10f;
            for (float v : history) max = Math.max(max, v);
            int baseY = wy + wh - 5;
            for (int i = 0; i < history.length; i++) {
                int bh = Math.max(1, (int) (12 * history[i] / max));
                int bx = wx + 5 + i * 3;
                ctx.fill(bx, baseY - bh, bx + 2, baseY, Draw.alpha(accent, 0.8f));
            }
        }

        // القفل (ElytraTarget)
        ElytraTarget elytraTarget = Md5n.modules.get(ElytraTarget.class);
        String lock = elytraTarget == null ? null : elytraTarget.hudText();
        if (lock != null) {
            String s = "Locked: " + lock;
            int pw = tr.getWidth(s) + 14;
            pillAt(ctx, tr, theme, accent, pulse, sw / 2 - pw / 2, y, s, accent, 1f);
        }

        // قائمة المودات (يمين) مع حركة دخول وخروج
        if (moduleList.get()) {
            int ry = 6;
            for (Module m : Md5n.modules.all()) {
                if (m == this || !m.hasToggle()) continue;
                float a = approach(theme, m, m.isEnabled() ? 1f : 0f, dt * 6f);
                if (a < 0.02f) continue;
                int pw = tr.getWidth(m.name) + 14;
                int px = sw - pw - 6 + (int) ((1f - a) * (pw + 10));
                pillAt(ctx, tr, theme, accent, pulse, px, ry, m.name, accent, a);
                ry += (int) (19 * a);
            }
        }
    }
}
