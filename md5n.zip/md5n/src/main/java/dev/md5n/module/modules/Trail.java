package dev.md5n.module.modules;

import dev.md5n.util.Colors;

public class Trail extends Cosmetic {
    public Trail() {
        super("Trail", "Particle trail behind you while you move (press F5 to see)",
                new String[]{"Line", "Wave", "Spiral", "Footsteps", "Ribbon", "Sparks", "Stardust", "Comet", "Rainbow Road", "Smoke"});
    }

    @Override
    protected void emit(String s) {
        if (speed < 0.04) return;   // يطلع بس وأنت تتحرك
        double sz = size.get();

        switch (s) {
            case "Wave": {
                double off = Math.sin(t * 6.0) * 0.35 * sz;
                free(off, 0.10, 0.0, col(0.0), 0.0, 0.0, 0.0);
                free(off, 0.12, 0.0, col(0.5), 0.0, 0.0, 0.0);
                break;
            }
            case "Spiral": {
                double a = t * 8.0;
                for (int k = 0; k < 2; k++) {
                    double aa = a + k * Math.PI;
                    free(Math.cos(aa) * 0.3 * sz, 0.25 + Math.sin(aa) * 0.2 * sz, 0.0, col(k / 2.0), 0.0, 0.0, 0.0);
                }
                break;
            }
            case "Footsteps": {
                if (tick % 4 != 0) return;
                double side = ((tick / 4) % 2 == 0) ? 0.15 : -0.15;
                for (int i = 0; i < 6; i++) {
                    double a = i * TAU / 6;
                    free(side + Math.cos(a) * 0.10 * sz, 0.05, Math.sin(a) * 0.15 * sz, col(i / 6.0), 0.0, 0.0, 0.0);
                }
                break;
            }
            case "Ribbon": {
                for (int k = -1; k <= 1; k += 2) {
                    free(k * 0.35 * sz, 0.9 + spread(0.03), -0.1, col(k > 0 ? 0.0 : 0.6), 0.0, 0.0, 0.0);
                }
                break;
            }
            case "Sparks": {
                int cnt = n(4);
                for (int i = 0; i < cnt; i++) {
                    free(spread(0.1), 0.2, 0.0, Colors.lerp(col(rnd()), 0xFFFFFF, 0.4),
                            spread(0.1), 0.02 + rnd() * 0.1, spread(0.1));
                }
                break;
            }
            case "Stardust": {
                int cnt = n(3);
                for (int i = 0; i < cnt; i++) {
                    free(spread(0.3 * sz), rnd() * 0.8, spread(0.3 * sz), col(rnd()), 0.0, 0.01, 0.0);
                }
                break;
            }
            case "Comet": {
                int cnt = n(5);
                for (int i = 0; i < cnt; i++) {
                    free(spread(0.08), 0.8 + spread(0.1), -0.2, Colors.lerp(col(0.0), 0xFFFFFF, rnd() * 0.6),
                            spread(0.02), spread(0.02), spread(0.02));
                }
                break;
            }
            case "Rainbow Road": {
                for (int k = 0; k < 7; k++) {
                    free((k - 3) * 0.1 * sz, 0.05, 0.0, Colors.hsv(k / 7.0, 0.7, 1.0), 0.0, 0.0, 0.0);
                }
                break;
            }
            case "Smoke": {
                int cnt = n(2);
                for (int i = 0; i < cnt; i++) {
                    int c = Colors.lerp(col(0.0), 0x808080, 0.5);
                    free(spread(0.1), 0.15, 0.0, c, spread(0.01), 0.02, spread(0.01));
                }
                break;
            }
            default: {
                // Line
                free(spread(0.03), 0.10, 0.0, col(0.0), 0.0, 0.0, 0.0);
                free(spread(0.03), 0.10, -0.05, col(0.5), 0.0, 0.0, 0.0);
                break;
            }
        }
    }
}
