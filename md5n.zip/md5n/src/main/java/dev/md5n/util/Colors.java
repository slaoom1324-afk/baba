package dev.md5n.util;

import dev.md5n.Md5n;
import dev.md5n.module.modules.ThemeSettings;
import net.minecraft.util.math.MathHelper;

/** نظام الألوان للكوزمتك: مربوط بألوان Theme (Visual). */
public final class Colors {
    private Colors() {}

    public static final String[] MODES = {"Theme", "Rainbow", "Gold", "Ice", "Fire", "Toxic", "Rose", "Void", "White"};

    /** لون Theme الحالي (يتبع الثيم المختار وRainbow Accent) بدون الشفافية. */
    public static int theme() {
        ThemeSettings theme = Md5n.modules == null ? null : Md5n.modules.get(ThemeSettings.class);
        return theme == null ? 0x55FFFF : (theme.accent() & 0xFFFFFF);
    }

    /** اللون النهائي للكوزمتك: إذا Sync Cosmetics شغّال يرجع لون Theme، وإلا لون الإعداد. */
    public static int resolve(String mode, double time, double phase) {
        ThemeSettings theme = Md5n.modules == null ? null : Md5n.modules.get(ThemeSettings.class);
        if (theme == null || theme.syncCosmetics()) return theme();
        switch (mode) {
            case "Rainbow": return hsv(((time / 8.0) + phase) % 1.0, 0.6, 1.0);
            case "Gold": return 0xFFC53D;
            case "Ice": return 0x8FE8FF;
            case "Fire": return 0xFF6A1A;
            case "Toxic": return 0x7CFF3A;
            case "Rose": return 0xFF6FA8;
            case "Void": return 0x8A4DFF;
            case "White": return 0xFFFFFF;
            default: return theme();
        }
    }

    public static int hsv(double h, double s, double v) {
        return MathHelper.hsvToRgb((float) h, (float) s, (float) v) & 0xFFFFFF;
    }

    public static int lerp(int a, int b, double t) {
        t = Math.max(0.0, Math.min(1.0, t));
        int r = (int) (((a >> 16) & 0xFF) + (((b >> 16) & 0xFF) - ((a >> 16) & 0xFF)) * t);
        int g = (int) (((a >> 8) & 0xFF) + (((b >> 8) & 0xFF) - ((a >> 8) & 0xFF)) * t);
        int bl = (int) ((a & 0xFF) + ((b & 0xFF) - (a & 0xFF)) * t);
        return (r << 16) | (g << 8) | bl;
    }

    public static int scale(int rgb, double f) {
        int r = (int) Math.min(255, ((rgb >> 16) & 0xFF) * f);
        int g = (int) Math.min(255, ((rgb >> 8) & 0xFF) * f);
        int b = (int) Math.min(255, (rgb & 0xFF) * f);
        return (r << 16) | (g << 8) | b;
    }

    /** يزيح الدرجة اللونية (hue) بعدد درجات، لإنتاج لون ثانوي من لون Theme. */
    public static int hueShift(int rgb, double degrees) {
        float r = ((rgb >> 16) & 0xFF) / 255f;
        float g = ((rgb >> 8) & 0xFF) / 255f;
        float b = (rgb & 0xFF) / 255f;
        float max = Math.max(r, Math.max(g, b));
        float min = Math.min(r, Math.min(g, b));
        float d = max - min;
        float h;
        if (d == 0f) h = 0f;
        else if (max == r) h = ((g - b) / d) % 6f;
        else if (max == g) h = (b - r) / d + 2f;
        else h = (r - g) / d + 4f;
        h /= 6f;
        if (h < 0f) h += 1f;
        float s = max == 0f ? 0f : d / max;
        double nh = (h + degrees / 360.0) % 1.0;
        if (nh < 0) nh += 1.0;
        return hsv(nh, s, max);
    }
}
